const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const base = path.join(__dirname, '../app/src/main/assets');
let count = 0;
const el = (text = '', attrs = {}, extra = {}) => ({
  innerText: text, getAttribute: k => attrs[k] ?? null,
  getClientRects: () => [{}], querySelector: () => null, ...extra
});
function run(name, {text = '', selectors = {}, href = 'https://www.google.com/maps/search/test/'} = {}) {
  const location = new URL(href);
  const document = {
    body: {innerText:text},
    querySelectorAll: s => selectors[s] || [],
    querySelector: s => (selectors[s] || [])[0] || null
  };
  return JSON.parse(JSON.stringify(vm.runInNewContext(fs.readFileSync(path.join(base,name),'utf8'), {document,location,URL,Set})));
}
function test(name, fn) { fn(); count++; console.log('PASS',name); }
test('Maps challenge is surfaced', () => assert.equal(run('maps.js',{text:'Sistemlerimiz olağan dışı trafik algıladı'}).blocked,true));
test('Consent page is blocked', () => assert.equal(run('maps.js',{href:'https://consent.google.com/m?continue=x'}).blocked,true));
test('Unknown markup is not accepted as empty results', () => assert.equal(run('maps.js',{text:'Loading...'}).readable,false));
test('Repeated place links deduplicate and scroll feed', () => {
  const feed=el('',{}, {scrollTop:0,clientHeight:600});
  const a=el('',{'aria-label':'Fixture A'},{href:'https://www.google.com/maps/place/fixture?x=1'});
  const r=run('maps.js',{selectors:{'a[href*="/maps/place/"]':[a,a],'[role="feed"]':[feed]}});
  assert.equal(r.items.length,1);assert.equal(r.items[0].name,'Fixture A');assert.equal(r.readable,true);assert.equal(r.scrollMoved,true);
});
test('Business detail extracts phone address and website without inventing data', () => {
  const r=run('maps.js',{selectors:{'h1':[el('Fixture Business')],'[data-item-id^="phone:tel:"]':[el('Telefon: +90 312 000 00 00')],'[data-item-id="address"]':[el('Adres: Fixture address')],'a[data-item-id="authority"]':[el('',{}, {href:'https://example.org/'})]}});
  assert.equal(r.detail,true);assert.equal(r.phone,'+90 312 000 00 00');assert.equal(r.address,'Fixture address');assert.equal(r.website,'https://example.org/');
});
test('Missing phone and website stay empty', () => {
  const r=run('maps.js',{selectors:{'h1':[el('Fixture Business')],'[data-item-id="address"]':[el('Fixture address')]}});
  assert.equal(r.phone,'');assert.equal(r.website,'');
});
test('Google results page heading is not a business', () => assert.equal(run('maps.js',{selectors:{'h1':[el('Sonuçlar')]}}).detail,false));
test('End marker is recognized', () => assert.equal(run('maps.js',{text:'Listenin sonuna ulaştınız.'}).end,true));
const link=(url,title)=>el('',{}, {href:url,querySelector:s=>s==='h3'?el(title):null});
test('Web search excludes social sites and retains only candidate evidence', () => {
  const r=run('search.js',{href:'https://www.google.com/search?q=fixture',selectors:{'#search, #rso':[el()], 'a[href]':[
    link('https://www.instagram.com/fixture','Social'),link('https://example.org/about','Fixture'),link('https://example.org/contact','Duplicate'),link('javascript:alert(1)','Bad')
  ]}});
  assert.equal(r.readable,true);assert.equal(r.candidates.length,1);assert.equal(r.candidates[0].url,'https://example.org/about');assert.equal(r.status,undefined);
});
test('Google redirect result resolves to target', () => {
  const r=run('search.js',{selectors:{'a[href]':[link('https://www.google.com/url?q=https%3A%2F%2Fexample.org','Fixture')]}});
  assert.equal(r.candidates[0].url,'https://example.org/');
});
test('Search captcha cannot produce a successful verification', () => assert.equal(run('search.js',{href:'https://www.google.com/sorry/index'}).blocked,true));
test('Unrecognized search page not treated as no website', () => assert.equal(run('search.js',{text:'Loading'}).readable,false));
test('Emails collected from visible text and mailto, deduplicated with source', () => {
  const r=run('contact.js',{href:'https://example.org/contact',text:'info@example.org',selectors:{'a[href^="mailto:"]':[el('',{href:'mailto:info@example.org?subject=Hi'})]}});
  assert.deepEqual(r.emails,['info@example.org']);assert.equal(r.source,'https://example.org/contact');
});
test('No email is generated when absent', () => assert.deepEqual(run('contact.js').emails,[]));
console.log(`${count} fixture tests passed. Live Maps / Android behavior is NOT covered.`);
