import com.caresoft.leadscout.Csv;
public class CsvTest {
    static void eq(String input, String expected) {
        if (!expected.equals(Csv.cell(input))) throw new AssertionError("CSV encoding mismatch");
    }
    public static void main(String[] args) {
        eq(null, "\"\"");
        eq("Ankara;Çankaya", "\"Ankara;Çankaya\"");
        eq("Bir \"Firma\"", "\"Bir \"\"Firma\"\"\"");
        eq("=HYPERLINK(\"x\")", "\"'=HYPERLINK(\"\"x\"\")\"");
        eq(" +903120000000", "\"' +903120000000\"");
        eq("@SUM(A1)", "\"'@SUM(A1)\"");
        eq("\n-1+1", "\"'\n-1+1\"");
        eq("İletişim\nAdresi", "\"İletişim\nAdresi\"");
        System.out.println("8 CSV cases passed.");
    }
}
