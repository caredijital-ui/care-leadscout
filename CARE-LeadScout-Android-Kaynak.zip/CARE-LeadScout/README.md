# CARE LeadScout — Android pilot

İl, ilçe, sektör ve isteğe bağlı mahalle/alternatif sektör adlarıyla Google Maps üzerinde araştırma yapan, cihazda kayıt tutan Android uygulamasının kaynak kodu.

**Bu paket hazır APK değildir. Android derlemesi, fiziksel cihaz testi ve canlı Google Maps uçtan uca testi bu ortamda yapılamadı.** Android SDK indirme adresi ağ erişiminde HTTP 403 verdi. Kaynak kodundaki JavaScript veri çıkarıcıları yapay DOM örnekleriyle test edilir; bu testler Google'ın güncel sayfalarında başarı garantisi değildir.

## Kullanım

1. İl, ilçe ve sektör gir. İstersen mahalleleri ve sektör eş anlamlılarını virgülle ekle.
2. Yeni taramayı başlat. Uygulama ön planda kalmalıdır. Arka plana geçince duraklar.
3. Google izin/doğrulama ekranlarını kendin tamamla, Devam'a bas. CAPTCHA çözme veya erişim engeli aşma yoktur.
4. Kayıtlar ekranından adresi ve sektör eşleşmesini incele. Google yakın ilçelerden veya benzer sektörlerden sonuç getirebilir.
5. İncele ekranından web sitesi adaylarını aç. İşletmeye ait olduğunu doğrularsan adresi site alanına girip kaydet.
6. Açık işletme sitesinde e-posta toplama düğmesine bas. Kayda eklemeden önce doğru işletme olduğunu onayla. İletişim sayfasına kendin geçebilirsin.
7. Görünen listeyi CSV, tüm kayıt ve bekleyen kuyruğu JSON olarak kaydet. JSON yedeği geri yüklenebilir.

## Durumların anlamı

| Durum | Anlam |
|---|---|
| Site bağlantısı var | Google Maps kaydında HTTPS web bağlantısı görüldü. Erişilebilirliği veya işletmeye aidiyeti ayrıca doğrulanmadı. |
| Kontrol gerekli | Henüz kontrol bitmedi veya web aramasında incelenecek adaylar var. |
| Tespit edilemedi | Okunabilir arama sonuçlarında filtrelerden geçen site adayı çıkmadı. Kesin olarak sitesi yok demek değildir. |
| Kullanıcı siteyi doğruladı | Kullanıcı site adresini kayıt ekranından onayladı. |

## Kapsam ve sınırlar

- Başlangıçta hiçbir işletme verisi yoktur. Test örnekleri uygulama kayıtlarına eklenmez.
- İl/ilçe/mahalle listesi servisi kullanılmaz; alanlar serbest metindir. Mahalleleri otomatik keşfetmez.
- En fazla 100 arama birleşimi, her aramada 120 kaydırma, toplam 500 yer adayı. Sınır veya ilerlememe nedeniyle erken biten tarama eksik olarak bildirilir.
- Places kuyruğunda URL, kayıtlarda kaynak URL veya aynı ad + aynı adres üzerinden birleştirme yapılır. Farklı yazılmış kayıtlar yine tekrar edebilir.
- Arama, detay ve web doğrulaması arasında bekler. Servis engelleri nedeniyle tam otonom çalışma garanti edilmez.
- Okunamayan adım durur; kullanıcı yeniden deneyebilir veya atlayabilir. Atlananlar JSON yedeğinde `skipped` listesine yazılır.
- Telefon formatının geçerliliği, arama yapılabilirliği ve işletmenin faaliyet durumunun doğrulanması bu sürümde yoktur.
- E-posta toplama otomatik tüm siteleri dolaşmaz: kullanıcı seçili işletmenin açık sayfasında başlatır.
- Yalnızca HTTPS sayfalar açılır; HTTP-only siteler elle harici tarayıcıda incelenmelidir.
- Google sayfalarının DOM yapısı değişirse `assets/maps.js` ve `assets/search.js` uyarlanmalıdır. Bu Google API ürünü değildir.
- API anahtarı, ücretli yapay zekâ, sunucu, reklam veya analiz SDK'sı kullanılmaz. İnternet/veri ve elektrik maliyeti kullanıcıya aittir.
- Toplu mesaj, arama veya ileti gönderme yoktur.
- Kurulumdan sonra kayıtlar yalnızca telefonda tutulur. Arama sorguları Google'a gönderilir. JSON/CSV dosyaları kişisel işletme araştırma verisi içerebilir; GitHub'a yalnızca kaynak kodunu koy.
- Otomatik Android yedeklemesi kapalıdır; kaldırmadan önce JSON yedeği al.

## Android APK üretimi

Gereken: JDK 17, Gradle 8.9, Android SDK platform 35. Uygulama Android 8.0+ hedefler, compileSdk 35 ve targetSdk 34 kullanır; bu kişisel pilot Play Store yayını için hazırlanmadı.

```sh
node tests/extractors.test.cjs
gradle :app:assembleDebug :app:lintDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

Gradle wrapper bu pakette bulunmaz; Gradle 8.9 kurulu olmalıdır. GitHub Actions dosyası bu sürümü otomatik kurar.

### Telefonda GitHub yolu

Yanındaki `CARE-Android-Kurulum.html` dosyasını tarayıcıda aç. Tek bir iş akışı dosyasının içeriğini kopyalaman için hazırlanmıştır. İş akışı proje kaynaklarını içerir, bağımlılıkları indirir, test/derleme/lint yapar ve başarılı olursa APK artifact üretir.

GitHub'da kaynak kod için bir depo aç; Add file → Create new file ile `.github/workflows/android.yml` oluştur ve kopyaladığın içeriği yapıştır. Actions → Android APK içinden çalışmayı takip et. Yeşil çalışmadaki `CARE-LeadScout-APK` artifact dosyasını indir ve ZIP'ten `app-debug.apk` dosyasını çıkar.

Standart GitHub Actions çalıştırıcıları açık kaynak depolarında ücretsizdir. Özel depolarda hesabın ücretsiz kotası geçerlidir; kotayı aşmadan çalıştır. Bu talimat ücretli kaynak oluşturmayı gerektirmez.

Debug APK geliştirme anahtarıyla imzalanır. Farklı derlemelerde anahtar değişebileceğinden güncelleme kurulumunda imza uyuşmazlığı olabilir. Önce JSON yedek al; gerekiyorsa eski uygulamayı kaldırıp yenisini kur ve yedeği yükle. Play Protect doğrulamasını kapatma; yalnızca kaynağını bildiğin APK'yı değerlendir.

## Doğrulama durumu

- 14 sentetik DOM testi: veri alanları, tekrar temizleme, onay/CAPTCHA tespiti, yanlış boş sonuçların reddi, site adayları ve e-posta çıkarımı.
- 8 CSV testi: ayırıcı, tırnak, satır sonu, Türkçe karakter ve formül başlangıcı koruması geçti.
- Java kaynakları: sözdizimi ayrıştırması geçti; Android sınıflarıyla tip kontrolü yapılmadı.
- XML ve YAML yapısı: yerel olarak doğrulandı.
- Java derleme / Android lint: henüz çalıştırılamadı; GitHub iş akışı çalıştıracak.
- Gerçek cihaz / güncel Google Maps taraması: henüz yapılmadı. Bu nedenle üretime hazır veya eksiksiz çalışır olarak sunulmaz.

## Teknik kaynaklar

- https://developer.android.com/build/releases/agp-8-7-0-release-notes
- https://developer.android.com/develop/ui/views/layout/webapps/webview
- https://developer.android.com/about/versions/oreo/background
- https://github.com/gradle/actions/blob/main/docs/setup-gradle.md
- https://docs.github.com/en/billing/concepts/product-billing/github-actions
