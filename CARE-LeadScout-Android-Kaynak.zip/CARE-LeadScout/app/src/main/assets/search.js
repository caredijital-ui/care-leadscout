(() => {
  const text = document.body?.innerText || '';
  const blocked = /(^|\.)consent\.google\./.test(location.hostname) || /\/sorry\//.test(location.pathname) || /unusual traffic|olağan dışı trafik|robot olmadığınızı/i.test(text);
  const candidates = [], seen = new Set();
  const excluded = /(^|\.)(google\.[a-z.]+|googleusercontent\.com|gstatic\.com|youtube\.com|facebook\.com|instagram\.com|linkedin\.com|yelp\.com|tripadvisor\.[a-z.]+|sahibinden\.com|armut\.com)$/i;
  for (const a of document.querySelectorAll('a[href]')) {
    const title = a.querySelector('h3')?.innerText?.trim();
    if (!title) continue;
    try {
      let u = new URL(a.href, location.href);
      if (u.pathname === '/url') u = new URL(u.searchParams.get('q') || u.searchParams.get('url'));
      if (!/^https:$/.test(u.protocol) || excluded.test(u.hostname) || seen.has(u.hostname)) continue;
      seen.add(u.hostname);
      candidates.push({ title, url: u.href });
    } catch (_) {}
  }
  const readable = !!document.querySelector('#search, #rso') || /did not match any documents|hiçbir belgeyle eşleşmedi|sonuç bulunamadı/i.test(text);
  // Candidates are never silently treated as the business's own website.
  return { blocked, readable, candidates: candidates.slice(0, 8), source: location.href };
})()
