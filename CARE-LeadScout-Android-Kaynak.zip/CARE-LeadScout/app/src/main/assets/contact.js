(() => {
  const emails = new Set();
  for (const a of document.querySelectorAll('a[href^="mailto:"]')) {
    const email = a.getAttribute('href').slice(7).split('?')[0].trim();
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) emails.add(email);
  }
  const text = document.body?.innerText || '';
  for (const e of text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || []) emails.add(e);
  return { emails: [...emails].slice(0, 10), source: location.href };
})()
