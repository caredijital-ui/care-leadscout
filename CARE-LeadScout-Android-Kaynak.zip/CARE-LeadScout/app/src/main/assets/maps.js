(() => {
  const txt = document.body?.innerText || '';
  const host = location.hostname;
  const blocked = /(^|\.)consent\.google\./.test(host) || /\/sorry\//.test(location.pathname) || /unusual traffic|olağan dışı trafik|robot olmadığınızı|I'm not a robot/i.test(txt);
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const visible = e => !!(e && e.getClientRects().length);
  const items = [];
  const seen = new Set();
  for (const a of document.querySelectorAll('a[href*="/maps/place/"]')) {
    const url = a.href.split('?')[0];
    if (!seen.has(url)) {
      seen.add(url);
      items.push({ url, name: clean(a.getAttribute('aria-label') || a.innerText) });
    }
  }
  const find = sel => Array.from(document.querySelectorAll(sel)).find(visible);
  const text = sel => clean(find(sel)?.innerText);
  const label = sel => clean(find(sel)?.getAttribute('aria-label'));
  const phone = (text('[data-item-id^="phone:tel:"]') || label('[data-item-id^="phone:tel:"]')).replace(/^(Telefon|Phone):\s*/i, '');
  const address = (text('[data-item-id="address"]') || label('[data-item-id="address"]')).replace(/^(Adres|Address):\s*/i, '');
  const authority = find('a[data-item-id="authority"]');
  const website = authority?.href || '';
  const heading = find('h1');
  const name = clean(heading?.innerText);
  const detail = !!name && !!(phone || address || authority) && !/^(Results|Sonuçlar|Google Maps|Google Haritalar)$/i.test(name);
  const feed = find('[role="feed"]');
  const end = /listenin sonuna ulaştınız|you.ve reached the end of the list|no results found|sonuç bulunamadı/i.test(txt);
  const before = feed ? feed.scrollTop : 0;
  if (feed) feed.scrollTop += Math.max(600, feed.clientHeight * .85);
  return { blocked, items, detail, name, phone, address, website, source: location.href,
    readable: !!feed || detail || end, end, scrollMoved: !!feed && before !== feed.scrollTop };
})()
