package com.caresoft.leadscout;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** Foreground-only pilot. No privileged JavaScript bridge and no remote backend. */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int BG = Color.rgb(14,23,33), PANEL = Color.rgb(25,38,51), ACCENT = Color.rgb(69,220,181);
    private LinearLayout root, body, browserPane;
    private TextView status, addressBar;
    private EditText city, district, sector, areas, aliases;
    private WebView web;
    private JSONObject state;
    private JSONArray records;
    private SharedPreferences prefs;
    private boolean running = false, inFlight = false;
    private int generation = 0, tab = 0, scrolls = 0, still = 0;
    private String exportPayload = "", browserRecord = "", message = "Hazır • Veriler bu telefonda saklanır";
    private boolean onlyProspects = true;
    private static final String UNKNOWN = "Kontrol gerekli", NO_SITE = "Tespit edilemedi", HAS_SITE = "Site bağlantısı var";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("leadscout", MODE_PRIVATE);
        try { state = new JSONObject(prefs.getString("state", "{}")); } catch (Exception e) { state = new JSONObject(); }
        records = state.optJSONArray("records");
        if (records == null) { records = new JSONArray(); put(state,"records",records); }
        makeBrowser();
        root = col(); root.setBackgroundColor(BG); root.setPadding(dp(14),dp(12),dp(14),dp(6));
        setContentView(root);
        TextView title = label("CARE  /  LEADSCOUT", 21); title.setTextColor(ACCENT); root.addView(title);
        root.addView(label("Müşteri araştırma asistanı · Pilot", 12));
        LinearLayout tabs = row();
        tabs.addView(button("Ara", () -> show(0)), weight());
        tabs.addView(button("Tarayıcı", () -> show(1)), weight());
        tabs.addView(button("Kayıtlar", () -> show(2)), weight()); root.addView(tabs);
        status = label(message, 12); status.setPadding(0,dp(8),0,dp(8)); root.addView(status);
        body = col(); root.addView(body, new LinearLayout.LayoutParams(-1,0,1));
        show(0);
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }
    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0,-2,1); }
    private TextView label(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE); return t; }
    private Button button(String s, Runnable r) { Button b = new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false); b.setOnClickListener(v -> r.run()); return b; }
    private EditText input(LinearLayout parent, String title, String value) {
        parent.addView(label(title,13)); EditText e = new EditText(this); e.setTextColor(Color.WHITE); e.setTextSize(15); e.setSingleLine(true); e.setText(value); parent.addView(e); return e;
    }
    private void say(String s) { message = s; if(status != null) status.setText(s); }
    private static void put(JSONObject o, String k, Object v) { try { o.put(k,v); } catch(JSONException ignored) {} }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss XXX", Locale.ROOT).format(new Date()); }
    private void save() { put(state,"records",records); prefs.edit().putString("state",state.toString()).apply(); }
    private JSONArray array(String k) { JSONArray a=state.optJSONArray(k); if(a==null){a=new JSONArray();put(state,k,a);} return a; }
    private void rememberForm() {
        if(city == null) return;
        put(state,"formCity",city.getText().toString().trim()); put(state,"formDistrict",district.getText().toString().trim());
        put(state,"formSector",sector.getText().toString().trim()); put(state,"formAreas",areas.getText().toString().trim()); put(state,"formAliases",aliases.getText().toString().trim()); save();
    }
    private void show(int target) {
        if(tab == 0) rememberForm();
        tab = target; body.removeAllViews();
        if(target == 1) { if(browserPane.getParent()!=null)((android.view.ViewGroup)browserPane.getParent()).removeView(browserPane); body.addView(browserPane,new LinearLayout.LayoutParams(-1,-1)); return; }
        ScrollView scroll = new ScrollView(this); LinearLayout pane=col(); scroll.addView(pane); body.addView(scroll);
        if(target == 0) {
            pane.addView(label("Hangi işletmeleri arayalım?",23));
            city=input(pane,"İl",state.optString("formCity")); district=input(pane,"İlçe",state.optString("formDistrict"));
            sector=input(pane,"Sektör",state.optString("formSector"));
            areas=input(pane,"Mahalleler (isteğe bağlı, virgülle)",state.optString("formAreas"));
            aliases=input(pane,"Sektörün diğer adları (isteğe bağlı, virgülle)",state.optString("formAliases"));
            pane.addView(button("Yeni taramayı başlat",this::newScan));
            pane.addView(button("Kaldığım yerden devam et",this::resume));
            pane.addView(button("Duraklat",() -> pause("Tarama duraklatıldı. Kayıtlar korundu.")));
            pane.addView(label("Mahalle girmezsen ilçe genelinde arama yapılır. Her sorguda en fazla 120 kaydırma, toplam 500 işletme adayı işlenir. Tam kapsama garantisi yoktur. Arka plana geçince tarama durur.",13));
            pane.addView(label("Google doğrulama veya çerez onayı gösterirse Tarayıcı sekmesinde kendin tamamla. Engeller aşılmaz. Google sayfa yapısı değişirse otomatik okuma çalışmayabilir.",13));
            pane.addView(button("Kullanım ve sınırlar",this::help));
        } else {
            pane.addView(label(records.length()+" kayıt",23));
            CheckBox filter=new CheckBox(this); filter.setText("Yalnızca site bağlantısı olmayanlar");filter.setTextColor(Color.WHITE);filter.setChecked(onlyProspects);
            filter.setOnCheckedChangeListener((v,c)->{onlyProspects=c;show(2);});pane.addView(filter);
            pane.addView(button("Görünen kayıtları CSV olarak kaydet",()->export(false)));
            pane.addView(button("Tüm verileri JSON yedekle",()->export(true)));
            pane.addView(button("JSON yedeğini geri yükle",()->{
                if(running){say("Önce taramayı duraklat.");return;}
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,13);
            }));
            if(records.length()==0)pane.addView(label("Henüz işletme yok. Ara sekmesinden başla. Örnek veya üretilmiş işletme verisi kullanılmaz.",15));
            for(int i=0;i<records.length();i++) {
                JSONObject r=records.optJSONObject(i); if(r==null || (onlyProspects&&!r.optString("website").isEmpty()))continue;
                LinearLayout card=col();card.setPadding(dp(12),dp(12),dp(12),dp(12));card.setBackgroundColor(PANEL);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));pane.addView(card,lp);
                card.addView(label(r.optString("name"),18));card.addView(label(r.optString("phone","Telefon bulunamadı"),14));
                card.addView(label(r.optString("address"),12));card.addView(label(r.optString("status",UNKNOWN)+" · "+r.optString("checkedAt"),12));
                if(!r.optString("website").isEmpty())card.addView(label(r.optString("website"),12));
                if(!r.optString("emails").isEmpty())card.addView(label(r.optString("emails"),12));
                card.addView(button("İncele / düzenle",()->editRecord(r)));
            }
        }
    }
    private void makeBrowser() {
        browserPane=col(); addressBar=label("Araştırma tarayıcısı",11);browserPane.addView(addressBar);
        LinearLayout controls=row();controls.addView(button("Duraklat",()->pause("Duraklatıldı.")),weight());
        controls.addView(button("Devam",this::resume),weight());
        controls.addView(button("Geri",()->{pause("Manuel gezinme");if(web.canGoBack())web.goBack();}),weight());browserPane.addView(controls);
        browserPane.addView(button("Okunamayan bu adımı atla",this::skipStep));
        web=new WebView(this); WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUseWideViewPort(true);s.setLoadWithOverviewMode(true);
        s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){return !safeUrl(req.getUrl().toString());}
            @Override public void onPageFinished(WebView v,String url){addressBar.setText(url);}
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError e){if(req.isForMainFrame()&&running)pause("Sayfa yüklenemedi. Bağlantını kontrol edip devam et.");}
            @Override public void onReceivedHttpError(WebView v,WebResourceRequest req,WebResourceResponse res){if(req.isForMainFrame()&&running&&res.getStatusCode()>=400)pause("Site erişimi durdu ("+res.getStatusCode()+"). Daha sonra devam et.");}
        });
        browserPane.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        browserPane.addView(button("Açık sayfadaki e-postaları seçili kayda al",this::captureEmail));
        browserPane.addView(label("Bu işlem yalnızca İncele ekranından seçtiğin işletmeye, açık sayfanın adresiyle birlikte e-posta ekler. Doğru işletmede olduğunu kontrol et.",11));
    }
    private boolean safeUrl(String url){try{return "https".equals(Uri.parse(url).getScheme())&&Uri.parse(url).getHost()!=null;}catch(Exception e){return false;}}
    private void newScan() {
        if(running){say("Yeni taramadan önce duraklat.");return;}
        rememberForm();
        if(state.optString("formCity").isEmpty()||state.optString("formDistrict").isEmpty()||state.optString("formSector").isEmpty()){say("İl, ilçe ve sektör gerekli.");return;}
        if(!state.optString("phase","done").equals("done")) {
            new AlertDialog.Builder(this).setTitle("Yeni tarama?").setMessage("Mevcut işletme kayıtları korunur. Bekleyen tarama kuyruğu yeni aramayla değiştirilir.").setPositiveButton("Başlat",(d,w)->initializeScan()).setNegativeButton("Vazgeç",null).show();
        } else initializeScan();
    }
    private void initializeScan(){
        pause("Yeni tarama hazırlanıyor");
        String c=state.optString("formCity"),d=state.optString("formDistrict"),s=state.optString("formSector");
        put(state,"city",c);put(state,"district",d);put(state,"sector",s);
        LinkedHashSet<String> terms=new LinkedHashSet<>();terms.add(s);for(String t:state.optString("formAliases").split(","))if(!t.trim().isEmpty())terms.add(t.trim());
        LinkedHashSet<String> places=new LinkedHashSet<>();places.add("");for(String a:state.optString("formAreas").split(","))if(!a.trim().isEmpty())places.add(a.trim());
        JSONArray q=new JSONArray();for(String a:places)for(String t:terms)if(q.length()<100)q.put((c+" "+d+" "+a+" "+t).trim());
        put(state,"queries",q);put(state,"places",new JSONArray());put(state,"queryIndex",0);put(state,"placeIndex",0);put(state,"phase","search");
        put(state,"limited",false);save();resume();
    }
    private void resume(){
        if(running)return;
        if(state.optString("phase","done").equals("done")){say("Bekleyen tarama yok. Yeni tarama başlat.");return;}
        running=true;generation++;scrolls=0;still=0;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0);
        show(1);step();
    }
    private void pause(String reason){running=false;generation++;inFlight=false;handler.removeCallbacksAndMessages(null);if(web!=null)web.stopLoading();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);save();say(reason);}
    private void later(long ms,Runnable r){int g=generation;handler.postDelayed(()->{if(running&&g==generation)r.run();},ms);}
    private void load(String url,Runnable after){
        if(!safeUrl(url)){pause("Geçersiz veya HTTPS olmayan bağlantı; elle kontrol gerekli.");return;}
        inFlight=true;web.loadUrl(url);int g=generation;
        handler.postDelayed(new Runnable(){int polls=0;public void run(){
            if(!running||g!=generation)return;
            if(web.getProgress()<100&&polls++<20){handler.postDelayed(this,1000);return;}
            if(web.getProgress()<100){pause("Sayfa zamanında yüklenmedi. Devam ile yeniden dene veya bu adımı atla.");return;}
            inFlight=false;later(2500,after);
        }},4000);
    }
    private void eval(String asset,java.util.function.Consumer<JSONObject> done){
        try(InputStream in=getAssets().open(asset)) {
            ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            int g=generation;web.evaluateJavascript(new String(out.toByteArray(),StandardCharsets.UTF_8), value->{
                if(g!=generation)return;
                try{done.accept(new JSONObject(value));}catch(Exception e){if(running)pause("Sayfa okunamadı. Otomatik sonuç kaydedilmedi; manuel kontrol gerekli.");else say("Sayfa okunamadı.");}
            });
        }catch(Exception e){pause("Okuma bileşeni açılamadı.");}
    }
    private boolean googlePage(){String host=Uri.parse(web.getUrl()==null?"":web.getUrl()).getHost();return host!=null&&(host.equals("google.com")||host.endsWith(".google.com")||host.equals("google.com.tr")||host.endsWith(".google.com.tr"));}
    private void step(){
        if(!running)return;
        String phase=state.optString("phase");
        if(phase.equals("search")){
            int i=state.optInt("queryIndex");JSONArray qs=array("queries");
            if(i>=qs.length()||array("places").length()>=500){if(array("places").length()>=500)put(state,"limited",true);put(state,"phase","detail");save();step();return;}
            scrolls=0;still=0;say("Arama "+(i+1)+"/"+qs.length()+" · "+qs.optString(i));
            load("https://www.google.com/maps/search/"+Uri.encode(qs.optString(i))+"/?hl=tr",this::readSearch);
        }else if(phase.equals("detail")){
            int i=state.optInt("placeIndex");JSONArray ps=array("places");
            if(i>=ps.length()){put(state,"phase","done");save();pause("Tarama bitti · "+records.length()+" kayıt. "+(state.optBoolean("limited")?"Tarama sınırına ulaşıldı; tüm işletmeler taranmadı.":"Sonuçların bölge ve işletme eşleşmesini incele."));show(2);return;}
            JSONObject p=ps.optJSONObject(i);if(p==null){advancePlace();return;}
            say("İşletme "+(i+1)+"/"+ps.length()+" · "+p.optString("name"));
            load(p.optString("url"),this::readDetail);
        }else if(phase.equals("verify"))verifyCurrent();
    }
    private void readSearch(){
        eval("maps.js",r->{
            if(r.optBoolean("blocked")||!googlePage()){pause("Google onayı veya doğrulama gerekli. Tarayıcıda tamamlayıp Devam'a bas.");return;}
            if(!r.optBoolean("readable")){pause("Harita sonuçları okunamadı. Sayfa yüklenmesini kontrol et; sonra Devam'a bas.");return;}
            JSONArray ps=array("places"),found=r.optJSONArray("items");int before=ps.length();
            if(found!=null)for(int j=0;j<found.length();j++)addPlace(found.optJSONObject(j));
            if(r.optBoolean("detail")) {JSONObject p=new JSONObject();put(p,"url",r.optString("source"));put(p,"name",r.optString("name"));addPlace(p);}
            still=ps.length()==before?still+1:0;scrolls++;save();
            say("Harita adayları: "+ps.length()+" · sorgu "+(state.optInt("queryIndex")+1)+"/"+array("queries").length());
            if(r.optBoolean("end")||r.optBoolean("detail")||still>=4||scrolls>=120||ps.length()>=500){
                if(!r.optBoolean("end")&&!r.optBoolean("detail"))put(state,"limited",true);
                put(state,"queryIndex",state.optInt("queryIndex")+1);save();later(3000,this::step);
            }else later(2500,this::readSearch);
        });
    }
    private void addPlace(JSONObject p){
        if(p==null||!safeUrl(p.optString("url"))||!p.optString("url").contains("/maps/place/"))return;
        JSONArray ps=array("places");String u=p.optString("url").split("\\?")[0];
        for(int i=0;i<ps.length();i++)if(ps.optJSONObject(i).optString("url").equals(u))return;
        if(ps.length()>=500)return;put(p,"url",u);put(p,"query",array("queries").optString(state.optInt("queryIndex")));ps.put(p);
    }
    private void readDetail(){
        eval("maps.js",r->{
            if(r.optBoolean("blocked")||!googlePage()){pause("Google doğrulamasını tamamlayıp Devam'a bas.");return;}
            if(!r.optBoolean("detail")){pause("İşletme ayrıntısı okunamadı. Boş kayıt oluşturulmadı. Sayfayı kontrol edip Devam'a bas.");return;}
            JSONObject candidate=array("places").optJSONObject(state.optInt("placeIndex"));
            String source=candidate.optString("url");JSONObject rec=findRecord(source);
            if(rec==null)for(int j=0;j<records.length();j++){
                JSONObject old=records.optJSONObject(j);
                if(old!=null&&!r.optString("address").isEmpty()&&normalize(old.optString("name")).equals(normalize(r.optString("name")))&&normalize(old.optString("address")).equals(normalize(r.optString("address")))){rec=old;break;}
            }
            if(rec==null){rec=new JSONObject();put(rec,"id",UUID.randomUUID().toString());put(rec,"source",source);records.put(rec);}
            put(rec,"name",r.optString("name"));put(rec,"phone",r.optString("phone"));put(rec,"address",r.optString("address"));
            put(rec,"cityQuery",state.optString("city"));put(rec,"districtQuery",state.optString("district"));put(rec,"sectorQuery",state.optString("sector"));
            put(rec,"query",candidate.optString("query"));put(rec,"checkedAt",today());put(rec,"locationCheck","Adres / sektör eşleşmesini inceleyin");
            if(!r.optString("website").isEmpty()&&safeUrl(r.optString("website"))){put(rec,"website",r.optString("website"));put(rec,"status",HAS_SITE);put(rec,"websiteEvidence",source);}
            if(rec.optString("website").isEmpty()){put(rec,"status",UNKNOWN);put(state,"currentId",rec.optString("id"));put(state,"phase","verify");save();later(3000,this::step);}else {save();advancePlace();}
        });
    }
    private JSONObject findRecord(String source){for(int i=0;i<records.length();i++){JSONObject r=records.optJSONObject(i);if(r!=null&&(r.optString("source").equals(source)||r.optString("id").equals(source)))return r;}return null;}
    private String normalize(String s){return s.toLowerCase(new Locale("tr","TR")).replaceAll("\\s+"," ").trim();}
    private void verifyCurrent(){
        JSONObject r=findRecord(state.optString("currentId"));if(r==null){advancePlace();return;}
        String q="\""+r.optString("name")+"\" "+r.optString("cityQuery")+" "+r.optString("districtQuery")+" "+r.optString("phone");
        say("Web sitesi kontrolü · "+r.optString("name"));
        load("https://www.google.com/search?hl=tr&q="+Uri.encode(q),()->eval("search.js",result->{
            if(result.optBoolean("blocked")||!googlePage()){pause("Arama için Google doğrulaması gerekli. Tamamlayıp Devam'a bas.");return;}
            if(!result.optBoolean("readable")){pause("Web arama sayfası okunamadı. İşletme 'Kontrol gerekli' olarak bırakıldı.");return;}
            JSONArray candidates=result.optJSONArray("candidates");if(candidates==null)candidates=new JSONArray();
            put(r,"candidates",candidates);put(r,"searchEvidence",result.optString("source"));put(r,"searchCheckedAt",today());
            put(r,"status",candidates.length()==0?NO_SITE:UNKNOWN);save();advancePlace();
        }));
    }
    private void advancePlace(){put(state,"placeIndex",state.optInt("placeIndex")+1);put(state,"phase","detail");save();later(3500,this::step);}
    private void skipStep(){
        if(state.optString("phase","done").equals("done")){say("Atlanacak tarama adımı yok.");return;}
        pause("Adım atlama onayı");new AlertDialog.Builder(this).setMessage("Bu adım kontrol edilmeden atlanacak ve yedekteki atlananlar listesine yazılacak. Devam edilsin mi?").setPositiveButton("Atla",(d,w)->{
            JSONObject skipped=new JSONObject();put(skipped,"phase",state.optString("phase"));put(skipped,"queryIndex",state.optInt("queryIndex"));put(skipped,"placeIndex",state.optInt("placeIndex"));put(skipped,"time",today());array("skipped").put(skipped);put(state,"limited",true);
            if(state.optString("phase").equals("search"))put(state,"queryIndex",state.optInt("queryIndex")+1);
            else{put(state,"placeIndex",state.optInt("placeIndex")+1);put(state,"phase","detail");}save();resume();
        }).setNegativeButton("Vazgeç",null).show();
    }
    private void open(String url,String id){pause("Manuel inceleme · otomatik tarama duraklatıldı.");browserRecord=id;show(1);if(safeUrl(url))web.loadUrl(url);else say("HTTPS bağlantısı gerekli.");}
    private void editRecord(JSONObject rec){
        pause("Kayıt incelemesi");ScrollView sc=new ScrollView(this);LinearLayout p=col();p.setPadding(dp(18),dp(10),dp(18),dp(10));sc.addView(p);
        p.addView(label(rec.optString("name"),20));p.addView(label("Aranan bölge: "+rec.optString("cityQuery")+" / "+rec.optString("districtQuery")+". Harita yakın bölge veya benzer sektör sonuçları gösterebilir.",12));
        EditText phone=input(p,"Telefon",rec.optString("phone")),website=input(p,"Doğruladığın web sitesi (https://)",rec.optString("website")),emails=input(p,"Açık işletme e-postaları",rec.optString("emails")),note=input(p,"Not / müşteri durumu",rec.optString("note"));
        p.addView(label("Durum: "+rec.optString("status",UNKNOWN),14));
        AlertDialog dialog=new AlertDialog.Builder(this).setView(sc).setPositiveButton("Kaydet",null).setNegativeButton("Kapat",null).create();
        p.addView(button("Google Maps kaynağı",()->{dialog.dismiss();open(rec.optString("source"),rec.optString("id"));}));
        p.addView(button("Web'de tekrar araştır",()->{dialog.dismiss();open("https://www.google.com/search?hl=tr&q="+Uri.encode(rec.optString("name")+" "+rec.optString("cityQuery")+" "+rec.optString("phone")),rec.optString("id"));}));
        JSONArray cs=rec.optJSONArray("candidates");if(cs!=null&&cs.length()>0)p.addView(label("Bulunan adaylar · İşletmeye ait oldukları doğrulanmadı",14));
        if(cs!=null)for(int i=0;i<cs.length();i++){JSONObject c=cs.optJSONObject(i);if(c==null)continue;String u=c.optString("url");p.addView(button(c.optString("title")+"\n"+u,()->{dialog.dismiss();open(u,rec.optString("id"));}));p.addView(button("Bu adresi site alanına al",()->website.setText(u)));}
        if(!rec.optString("website").isEmpty())p.addView(button("Kayıtlı siteyi aç",()->{dialog.dismiss();open(rec.optString("website"),rec.optString("id"));}));
        p.addView(button("Kaydı sil",()->new AlertDialog.Builder(this).setMessage("Bu işletme kaydı silinsin mi?").setPositiveButton("Sil",(d,w)->{JSONArray kept=new JSONArray();for(int i=0;i<records.length();i++){JSONObject r=records.optJSONObject(i);if(!r.optString("id").equals(rec.optString("id")))kept.put(r);}records=kept;save();dialog.dismiss();show(2);}).setNegativeButton("Vazgeç",null).show()));
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String url=website.getText().toString().trim();if(!url.isEmpty()&&!safeUrl(url)){website.setError("https:// ile başlayan geçerli bir adres gir");return;}
            put(rec,"phone",phone.getText().toString().trim());put(rec,"website",url);put(rec,"emails",emails.getText().toString().trim());put(rec,"note",note.getText().toString());
            put(rec,"status",url.isEmpty()?UNKNOWN:"Kullanıcı siteyi doğruladı");put(rec,"editedAt",today());save();dialog.dismiss();show(2);
        }));dialog.show();
    }
    private void captureEmail(){
        pause("E-posta kontrolü");JSONObject r=findRecord(browserRecord);if(r==null){say("Önce Kayıtlar → İncele üzerinden bir işletmenin sayfasını aç.");return;}
        eval("contact.js",result->{JSONArray values=result.optJSONArray("emails");StringBuilder emailBuilder=new StringBuilder();if(values!=null)for(int j=0;j<values.length();j++){if(j>0)emailBuilder.append(", ");emailBuilder.append(values.optString(j));}String emails=emailBuilder.toString();
            if(emails.isEmpty()){say("Bu sayfada açık e-posta bulunamadı.");return;}
            String source=result.optString("source");new AlertDialog.Builder(this).setTitle(r.optString("name")).setMessage("Bu e-postalar doğru işletmeye mi ait?\n\n"+emails+"\n\nKaynak: "+source).setPositiveButton("Kayda ekle",(d,w)->{put(r,"emails",emails);put(r,"emailEvidence",source);put(r,"emailCheckedAt",today());save();say("E-postalar kaynak bağlantısıyla kaydedildi.");}).setNegativeButton("Vazgeç",null).show();
        });
    }
    private void export(boolean json){
        pause("Dosya dışa aktarımı");
        if(json)exportPayload=state.toString();else{
            String[] keys={"name","phone","address","website","status","emails","source","searchEvidence","emailEvidence","checkedAt","cityQuery","districtQuery","sectorQuery","locationCheck","note"};
            StringBuilder out=new StringBuilder("\uFEFFİşletme;Telefon;Adres;Web sitesi;Durum;E-posta;Maps kaynağı;Arama kaynağı;E-posta kaynağı;Kontrol zamanı;Aranan il;Aranan ilçe;Aranan sektör;Konum kontrolü;Not\r\n");
            for(int i=0;i<records.length();i++){JSONObject r=records.optJSONObject(i);if(r==null||(onlyProspects&&!r.optString("website").isEmpty()))continue;for(int k=0;k<keys.length;k++){if(k>0)out.append(';');out.append(Csv.cell(r.optString(keys[k])));}out.append("\r\n");}exportPayload=out.toString();
        }
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(json?"application/json":"text/csv");i.putExtra(Intent.EXTRA_TITLE,json?"CARE-LeadScout-Yedek.json":"CARE-Musteri-Listesi.csv");startActivityForResult(i,12);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        if(request==12){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new IOException();out.write(exportPayload.getBytes(StandardCharsets.UTF_8));say("Dosya kaydedildi.");}catch(Exception e){say("Dosya kaydedilemedi.");}return;}
        if(request==13){try(InputStream in=getContentResolver().openInputStream(data.getData())){
            if(in==null)throw new IOException();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;
            while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>8_000_000)throw new IOException();}
            JSONObject restored=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));JSONArray rs=restored.optJSONArray("records");if(rs==null)throw new IOException();
            for(int j=0;j<rs.length();j++){JSONObject r=rs.optJSONObject(j);if(r==null||r.optString("id").isEmpty()||r.optString("name").isEmpty())throw new IOException();}
            new AlertDialog.Builder(this).setTitle("Yedeği geri yükle").setMessage("Mevcut kayıtlar bu yedekteki "+rs.length()+" kayıtla değiştirilsin mi? Önce mevcut kayıtlarını yedekleyebilirsin.").setPositiveButton("Geri yükle",(d,w)->{state=restored;records=rs;save();say("Yedek yüklendi. Tarama kendiliğinden başlamaz.");show(2);}).setNegativeButton("Vazgeç",null).show();
        }catch(Exception e){say("Geçerli CARE yedeği okunamadı (en fazla 8 MB).");}}
    }
    private void help(){new AlertDialog.Builder(this).setTitle("CARE LeadScout · Pilot").setMessage("İl, ilçe ve sektör gir. Mahalleler ve alternatif sektör adları kapsamı artırır. Google Maps sonuçları okunur, site bağlantısı olmayan işletmeler web aramasında kontrol edilir.\n\nTespit edilemedi: Bu aramada uygun site adayı görülmedi; kesinlikle sitesi yok anlamına gelmez.\nKontrol gerekli: Aday site var veya doğrulama tamamlanmadı.\nSite bağlantısı var: Maps üzerinde bağlantı görüldü; sitenin çalıştığı test edilmedi.\n\nBölge ve sektör eşleşmesini adres üzerinden incele. Yakın ilçe sonuçları çıkabilir. Veriler cihazında saklanır; aramalar Google'a gider. E-posta toplama işletme sayfasında elle başlatılır. Mesaj gönderilmez.\n\nÜcretli API veya sunucu yok. Bu sürüm fiziksel Android cihazında ve canlı Google Maps üzerinde henüz doğrulanmadı. Google erişimi ve sayfa değişiklikleri nedeniyle otomasyon durabilir.").setPositiveButton("Tamam",null).show();}
    @Override protected void onPause(){super.onPause();if(running)pause("Uygulama arka plana geçti. Devam ile sürdürebilirsin.");else save();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);web.destroy();super.onDestroy();}
    @Override public void onBackPressed(){if(tab!=0)show(0);else super.onBackPressed();}
}
