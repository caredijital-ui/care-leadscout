package com.caresoft.leadscout;

public final class Csv {
    private Csv() {}
    public static String cell(String value) {
        if (value == null) value = "";
        if (value.matches("(?s)^\\s*[=+@-].*")) value = "'" + value;
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }
}
